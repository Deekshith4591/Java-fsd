/**
 * 
 */
/**
 * 
 */
module example8 {
}