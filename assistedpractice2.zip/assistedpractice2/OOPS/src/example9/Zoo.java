package example9;
interface Animal {
    default void speak() {
        System.out.println("Animal speaks");
    }
}

// Create two interfaces that extend the Animal interface
interface Lion extends Animal {
    default void speak() {
        System.out.println("Lion roars");
    }
}

interface Elephant extends Animal {
    default void speak() {
        System.out.println("Elephant trumpets");
    }
}

// Create a class that implements both Lion and Elephant interfaces
class ZooAnimal implements Lion, Elephant {
    // To resolve the diamond problem, override the conflicting default method
    @Override
    public void speak() {
        Lion.super.speak(); // Call the speak method from the Lion interface
        Elephant.super.speak(); // Call the speak method from the Elephant interface
    }
}

public class Zoo {
    public static void main(String[] args) {
        ZooAnimal zooAnimal = new ZooAnimal();
        zooAnimal.speak(); // Calls the overridden speak method in the ZooAnimal class
    }
}
