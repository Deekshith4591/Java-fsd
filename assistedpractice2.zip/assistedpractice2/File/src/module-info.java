/**
 * 
 */
/**
 * 
 */
module example7 {
}