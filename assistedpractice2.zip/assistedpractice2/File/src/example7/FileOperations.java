package example7;
import java.io.*;
public class FileOperations {
	public static void createFile(String fileName) {
        try {
            File file = new File(fileName);
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public static void readFile(String fileName) {
        try {
            File file = new File(fileName);
            BufferedReader br = new BufferedReader(new FileReader(file));

            String line;
            System.out.println("File content:");
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }

            br.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public static void updateFile(String fileName, String content) {
        try {
            FileWriter fw = new FileWriter(fileName, true); // Set true for append mode
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(content);
            bw.close();
            System.out.println("Content updated.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public static void deleteFile(String fileName) {
        File file = new File(fileName);
        if (file.delete()) {
            System.out.println("File deleted: " + file.getName());
        } else {
            System.out.println("Failed to delete the file.");
        }
    }

    public static void main(String[] args) {
        String fileName = "Deekshith.txt";

        // Create a file
        createFile(fileName);

        // Write content to the file
        updateFile(fileName, "This is  Deekshith text.\n");

        // Read content from the file
        readFile(fileName);

        // Append content to the file
        updateFile(fileName, "This line is appended.\n");

        // Read updated content
        readFile(fileName);

        // Delete the file
        deleteFile(fileName);
    }

}
