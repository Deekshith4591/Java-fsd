package customexception;

public class CustomException extends Exception {
	
	 public CustomException(String message) {
	     super(message);
	 }

	 // Method that throws a custom exception
	 public static void checkNumber(int number) throws CustomException {
	     if (number < 0) {
	         throw new CustomException("Number cannot be negative");
	     }
	     System.out.println("Number is: " + number);
	 }

	 public static void main(String[] args) {
	     try {
	         checkNumber(-8);
	     } catch (CustomException e) {
	         System.out.println("CustomException caught: " + e.getMessage());
	     } finally {
	         System.out.println("Finally block executed.");
	     }

	     System.out.println("Program continues after exception handling.");
	 }

}
