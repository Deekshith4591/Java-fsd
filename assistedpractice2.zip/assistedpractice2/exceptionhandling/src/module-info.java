/**
 * 
 */
/**
 * 
 */
module Example6 {
}