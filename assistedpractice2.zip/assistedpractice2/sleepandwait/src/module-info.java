/**
 * 
 */
/**
 * 
 */
module example2 {
}