package example3;

public class Synchronization {
	public void send(String msg) {
        System.out.println("Sending\t" + msg);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted.");
        }
        System.out.println("\n" + msg + " Sent");
    }
}

// Class for sending a message using Threads
class ThreadedSend extends Thread {
    private String msg;
    private Synchronization synchronization;

    // Receives a message object and a string
    // message to be sent
    ThreadedSend(String m, Synchronization obj) {
        msg = m;
        synchronization = obj;
    }

    public void run() {
        // Only one thread can send a message
        // at a time.
        synchronized (synchronization) {
            // Synchronize on the send object
            synchronization.send(msg);
        }
    }
}

// Driver class
public class SyncDemo {
    public static void main(String args[]) {
        Synchronization send = new Synchronization();
        ThreadedSend S1 = new ThreadedSend("Hi", send);
        ThreadedSend S2 = new ThreadedSend("Bye", send);

        // Start two threads of ThreadedSend type
        S1.start();
        S2.start();

        // Wait for threads to end
        try {
            S1.join();
            S2.join();
        } catch (InterruptedException e) {
            System.out.println("Interrupted");
        }
    }

}
