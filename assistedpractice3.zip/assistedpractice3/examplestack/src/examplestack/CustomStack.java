package examplestack;

public class CustomStack {
	 private static final String stack = null;
	private int[] stackArray;
	    private int top;
	    private int capacity;

	    public CustomStack(int capacity) {
	        this.capacity = capacity;
	        stackArray = new int[capacity];
	        top = -1;
	    }

	    public void push(int data) {
	        if (isFull()) {
	            System.out.println("Stack is full. Cannot push " + data);
	            return;
	        }
	        stackArray[++top] = data;
	    }

	    public int pop() {
	        if (isEmpty()) {
	            System.out.println("Stack is empty. Cannot pop.");
	            return -1; // Return a sentinel value indicating an empty stack.
	        }
	        return stackArray[top--];
	    }

	    public boolean isFull() {
	        return top == capacity - 1;
	    }

	    public boolean isEmpty() {
	        return top == -1;
	    }

	    public void printStack() {
	        if (isEmpty()) {
	            System.out.println("Stack is empty.");
	            return;
	        }
	        System.out.print("Stack: ");
	        for (int i = 0; i <= top; i++) {
	            System.out.print(stackArray[i] + " ");
	        }
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        CustomStack customStack = new CustomStack(5);

	        customStack.push(22);
	        customStack.push(43);
	        customStack.push(23);
	        customStack.push(45);

	        customStack.printStack();

	        int poppedElement = customStack.pop();
	        System.out.println("Popped element: " + poppedElement);
	        customStack.printStack();

	        customStack.push(45);
	        customStack.printStack();
	    }
	}
