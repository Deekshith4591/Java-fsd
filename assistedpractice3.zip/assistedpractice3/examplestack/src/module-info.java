/**
 * 
 */
/**
 * 
 */
module examplestack {
}