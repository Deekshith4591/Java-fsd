package examplequeue;
public class CustomQueue {
	private int[] queueArray;
    private int front;
    private int rear;
    private int size;
    private int capacity;
    public CustomQueue(int capacity) {
        this.capacity = capacity;
        queueArray = new int[capacity];
        front = 0;
        rear = -1;
        size = 0;
    }

    public void enqueue(int data) {
        if (isFull()) {
            System.out.println("Queue is full. Cannot enqueue " + data);
            return;
        }
        rear = (rear + 1) % capacity;
        queueArray[rear] = data;
        size++;
    }

    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty. Cannot dequeue.");
            return -1; // Return a sentinel value indicating an empty queue.
        }
        int data = queueArray[front];
        front = (front + 1) % capacity;
        size--;
        return data;
    }

    public boolean isFull() {
        return size == capacity;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void printQueue() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }
        System.out.print("Queue: ");
        int index = front;
        for (int i = 0; i < size; i++) {
            System.out.print(queueArray[index] + " ");
            index = (index + 1) % capacity;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        CustomQueue customQueue = new CustomQueue(5);
        customQueue.enqueue(56);
        customQueue.enqueue(76);
        customQueue.enqueue(78);
        customQueue.enqueue(89);
        customQueue.printQueue();
        int dequeuedElement = customQueue.dequeue();
        System.out.println("Dequeued element: " + dequeuedElement);
        customQueue.printQueue();
        customQueue.enqueue(56);
        customQueue.printQueue();
    }

}
