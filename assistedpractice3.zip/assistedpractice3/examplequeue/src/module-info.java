/**
 * 
 */
/**
 * 
 */
module examplequeue {
}