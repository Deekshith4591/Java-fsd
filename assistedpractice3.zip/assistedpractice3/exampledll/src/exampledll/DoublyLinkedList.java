package exampledll;
class DLL {
    int data;
    DLL next;
    DLL prev;

    public DLL(int data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}
class DoublyLinkedList {
    DLL head;

    public void insert(int data) {
        DLL newDLL = new DLL(data);

        if (head == null) {
            head = newDLL;
        } else {
            DLL temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newDLL;
            newDLL.prev = temp;
        }
    }

    public void traverseForward() {
        System.out.println("Traversing in forward direction:");
        DLL temp = head;
        while (temp != null) {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        }
        System.out.println("null");
    }

    public void traverseBackward() {
        System.out.println("Traversing in backward direction:");
        DLL temp = head;
        while (temp != null && temp.next != null) {
            temp = temp.next;
        }
        while (temp != null) {
            System.out.print(temp.data + " -> ");
            temp = temp.prev;
        }
        System.out.println("null");
    }
    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();
        list.insert(25);
        list.insert(50);
        list.insert(75);
        list.insert(100);
        list.insert(125);

        list.traverseForward();
        list.traverseBackward();
    }
}
