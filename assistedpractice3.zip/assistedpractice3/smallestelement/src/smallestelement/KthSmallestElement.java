package smallestelement;
import java.util.Arrays;
public class KthSmallestElement {
	public static int kthSmallest(Integer[] arr, int k) {
        if (k <= 0 || k > arr.length) {
            throw new IllegalArgumentException("Invalid value of k");
        }

        Arrays.sort(arr);

        return arr[k - 1];
    }

    public static void main(String[] args) {
        Integer arr[] = new Integer[] { 12, 43, 6, 87, 23 };
        int k = 4;

        try {
            int kthSmallestElement = kthSmallest(arr, k);
            System.out.print("The " + k + "th smallest element is " + kthSmallestElement);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

}
