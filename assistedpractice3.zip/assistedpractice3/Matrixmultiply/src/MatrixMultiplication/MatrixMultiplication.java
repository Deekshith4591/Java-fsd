package MatrixMultiplication;

public class MatrixMultiplication {
	public static void main(String args[]) {  
        // Creating two matrices    
        int matrixA[][] = {{1, 1, 1}, {2, 2, 2}, {3, 3, 3}};    
        int matrixB[][] = {{1, 1, 1}, {2, 2, 2}, {3, 3, 3}};            
        // Creating another matrix to store the multiplication result    
        int resultMatrix[][] = new int[3][3];  // 3 rows and 3 columns     
        for(int i = 0; i < 3; i++) {    
            for(int j = 0; j < 3; j++) {    
                resultMatrix[i][j] = 0;      
                for(int k = 0; k < 3; k++) {      
                    resultMatrix[i][j] += matrixA[i][k] * matrixB[k][j];      
                } // end of k loop  
                System.out.print(resultMatrix[i][j] + " ");  
            } // end of j loop  
            System.out.println(); // new line    
        }    
    }

}

