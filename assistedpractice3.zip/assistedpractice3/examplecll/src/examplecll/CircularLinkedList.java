package examplecll;
class CLL {
    int data;
    CLL next;

    public CLL(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    CLL head;

    public CircularLinkedList() {
        head = null;
    }

    public void insert(int data) {
        CLL newCLL = new CLL(data);

        if (head == null) {
            newCLL.next = newCLL;
            head = newCLL;
        } else if (data <= head.data) {
            CLL temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newCLL;
            newCLL.next = head;
            head = newCLL;
        } else {
            CLL temp = head;
            while (temp.next != head && temp.next.data < data) {
                temp = temp.next;
            }
            newCLL.next = temp.next;
            temp.next = newCLL;
        }
    }

    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        CLL temp = head;
        do {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        } while (temp != head);

        System.out.println();
    }

    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();

        list.insert(50);
        list.insert(30);
        list.insert(70);
        list.insert(20);
        list.insert(40);

        System.out.println("Original Circular Linked List:");
        list.display();

        int newData = 60;
        list.insert(newData);

        System.out.println("Circular Linked List after inserting " + newData + ":");
        list.display();
    }
}
