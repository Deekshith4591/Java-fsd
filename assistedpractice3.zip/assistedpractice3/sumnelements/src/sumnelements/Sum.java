package sumnelements;
public class Sum {
	static int sumNatural(int n) {
        int sum = (n * (n + 1)) / 2;
        return sum;
    }
    static int sumInRange(int L, int r) {
        if (L > r) {
            throw new IllegalArgumentException("Invalid range: L is greater than R");
        }
        return sumNatural(r) - sumNatural(L - 1);
    }
    public static void main(String[] args) {
        int L = 4, r = 9;
        try {
            System.out.println("Sum of Natural numbers from L to R is " + sumInRange(L, r));
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}

