/**
 * 
 */
/**
 * 
 */
module Arrayrotation {
}