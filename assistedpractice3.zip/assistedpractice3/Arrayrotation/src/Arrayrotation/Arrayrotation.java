package Arrayrotation;

public class Arrayrotation {
	public void rotate(int[] nums, int k) {
        int n = nums.length;
        if (n == 0 || k % n == 0) {
            return; 
        }

        k = k % n; // Calculating effective rotation amount

        int[] result = new int[n];
        for (int i = 0; i < n; i++) {
            result[i] = nums[(i - k + n) % n];
        }

        System.arraycopy(result, 0, nums, 0, n);
    }

    public static void main(String[] args) {
        Arrayrotation arrayRotation = new Arrayrotation();
        int[] arr = {9, 2, 6, 4, 3, 1, 8};
        int rotationAmount = 5;
        arrayRotation.rotate(arr, rotationAmount);

        System.out.print("Rotated Array: ");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }

}
