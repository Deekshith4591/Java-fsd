/**
 * 
 */
/**
 * 
 */
module exponentialsearch {
}