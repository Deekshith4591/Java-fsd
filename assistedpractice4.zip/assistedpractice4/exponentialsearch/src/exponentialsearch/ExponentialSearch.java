package exponentialsearch;

public class ExponentialSearch {
	    public static int exponentialSearch(int[] arr, int target) {
	        int bound = 1;

	        while (bound < arr.length && arr[bound] <= target) {
	            bound *= 2;
	        }
	        return binarySearch(arr, bound / 2, Math.min(bound, arr.length - 1), target);
	    }

	    public static int binarySearch(int[] arr, int left, int right, int target) {
	        while (left <= right) {
	            int mid = left + (right - left) / 2;

	            if (arr[mid] == target) {
	                return mid;
	            }

	            if (arr[mid] < target) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }

	        return -1; 
	    }

	    public static void main(String[] args) {
	        int[] arr = {3, 6, 8, 9, 56, 12, 14, 96, 12};
	        int target = 6;

	        int result = exponentialSearch(arr, target);

	        if (result != -1) {
	            System.out.println("Element found at index " + result);
	        } else {
	            System.out.println("Element not found in the array");
	        }
	    }
	}
