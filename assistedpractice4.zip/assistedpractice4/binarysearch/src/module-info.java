/**
 * 
 */
/**
 * 
 */
module binarysearch {
}