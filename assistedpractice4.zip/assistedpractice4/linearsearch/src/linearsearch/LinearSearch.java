package linearsearch;
public class LinearSearch {
		   public static void main(String args[]){
		      int array[] = {23,50, 35, 73, 56, 87};
		      int size = array.length;
		      int value = 56;
		      boolean found = false; 

		      for (int i = 0; i < size; i++){ 
		         if (array[i] == value){
		            System.out.println("Element found at index: " + i);
		            found = true; 
		            break; 
		         }
		      }
		      if (!found) {
		         System.out.println("Element not found");
		      }
		   }
		}



