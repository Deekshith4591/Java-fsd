package deekshith;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/SessionDemo")
public class SessionDemoServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Get the session object
        HttpSession session = request.getSession();

        // Get user input from the HTML form
        String username = request.getParameter("username");

        // Set session attribute for username
        session.setAttribute("username", username);

        // Set the response content type
        response.setContentType("text/html");

        // Get a PrintWriter to write HTML response
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Session Tracking Example</title></head><body>");
        out.println("<h1>Session Tracking Example</h1>");
        out.println("<p>Welcome, " + username + "!</p>");
        out.println("<p>Session ID: " + session.getId() + "</p>");
        out.println("<form method='post' action='SessionDemo'>");
        out.println("Enter your name: <input type='text' name='username'><br>");
        out.println("<input type='submit' value='Submit'>");
        out.println("</form>");
        out.println("</body></html>");
    }
}
