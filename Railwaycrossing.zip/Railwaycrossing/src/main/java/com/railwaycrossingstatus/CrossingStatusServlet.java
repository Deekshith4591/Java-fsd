package com.railwaycrossingstatus;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
@WebServlet("/CrossingStatusServlet")
public class CrossingStatusServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String searchQuery = request.getParameter("searchQuery");
        // Perform database query based on searchQuery
        List<String> crossingStatus = new ArrayList<>(); // Dummy data, replace with actual data
        // Set crossingStatus in request attribute and forward to crossingStatus.jsp
        request.setAttribute("crossingStatus", crossingStatus);
        RequestDispatcher dispatcher = request.getRequestDispatcher("crossingStatus.jsp");
        dispatcher.forward(request, response);
    }
}
