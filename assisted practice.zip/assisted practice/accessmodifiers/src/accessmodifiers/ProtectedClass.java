package accessmodifiers;

public class ProtectedClass {

}
