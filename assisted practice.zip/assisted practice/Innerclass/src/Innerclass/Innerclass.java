package Innerclass;

public class Innerclass {
	private String message="Hi Deekshith"; 
	class Inner{ 
	 void hello(){System.out.println(message+", Let us start learning Java...");} 
	} 
	public static void main(String[] args) {
		Innerclass obj=new Innerclass();
		Innerclass.Inner in=obj.new Inner(); 
	    in.hello(); 
	}

}
