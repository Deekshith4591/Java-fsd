package StringExpressions;
import java.util.regex.*;
public class StringExpressions {
	public static void main(String[] args) {
        String datePattern = "\\d{2}/\\d{2}/\\d{4}";
        String testString = "Today's date is 12/09/2023.";

        // Pattern and Matcher objects
        Pattern pattern = Pattern.compile(datePattern);
        Matcher matcher = pattern.matcher(testString);
        if (matcher.find()) {
            System.out.println("Date found: " + matcher.group());
        } else {
            System.out.println("No date found.");
        }
    }
	

}
