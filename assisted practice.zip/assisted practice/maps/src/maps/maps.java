package maps;
import java.util.*;
public class maps {
	public static void main(String[] args) {
		  HashMap<Integer,String> a =new HashMap<Integer,String>();    //1. HASHMAP  
	      a.put(1,"Apple");    
	      a.put(2,"Grape");    
	      a.put(3,"Pineapple");   
	      System.out.println("Elements of Hashmap ");  
	        for(Map.Entry<Integer,String> m : a.entrySet()){    
	                System.out.println(m.getKey()+" "+m.getValue());    
	        }
	      
	      System.out.println("\n");
	         
	      Hashtable<Integer,String> b =new Hashtable<Integer,String>();  //2. HASHTABLE
	      b.put(1,"Deekshith");  
	      b.put(2,"Sushmitha");  
	      b.put(3,"Kohli");  
	      System.out.println("Elements of HashTable");  
          for(Map.Entry<Integer,String> n : b.entrySet()){    
	                System.out.println(n.getKey()+" "+n.getValue());    
	        }
	      
	      
        System.out.println("\n");
	      
	      TreeMap<Integer,String> c = new TreeMap<Integer,String>();   //3. TREEMAP 
	      c.put(1,"Jan");    
	      c.put(3,"Feb"); 
	      c.put(2,"Mar");
	      System.out.println("Elements of TreeMap ");  
	        for(Map.Entry<Integer,String> o : c.entrySet()){    
	                System.out.println(o.getKey()+" "+o.getValue());    
	        }    
	}


}
